
const Theme = () => {
    return (
        <section class="tems">
            <h2>Оберіть тему</h2>
            <div class="scroll">
                <div class="navigator">
                    <div class="img"><img src="" alt="" /></div>
                    <div class="img"><img src="" alt="" /></div>
                </div>
                <div class="scroll_slider">
                    <div class="blok">
                        <div class="img"><img src="" alt="" /></div>
                        <p>text</p>
                    </div>
                </div>
            </div>
        </section>
    )
}
export { Theme }