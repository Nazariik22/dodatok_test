
const Comments = () => {
    return (
        <aside>
            <div class="addcoment">
                <div class="img"><img src="" alt="" /></div>
                <p>Залишити коментар</p>
            </div>
            <div class="comments">
                <div class="img"><img src="" alt="" /></div>
                <div class="blok">
                    <h4>Прізвище та Ім'я</h4>
                    <p>Ваш коментар</p>
                </div>
            </div>
        </aside>
    )
}
export { Comments }